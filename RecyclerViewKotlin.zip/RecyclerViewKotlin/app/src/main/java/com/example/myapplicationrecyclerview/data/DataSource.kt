package com.example.myapplicationrecyclerview.data

import com.example.myapplicationrecyclerview.models.BlogPost

class DataSource {

    companion object {

        fun createDataSet(): ArrayList<BlogPost> {
            val list = ArrayList<BlogPost>()
            list.add(
                BlogPost(
                    0,
                    "Spongebob Squarepants",
                    "An energetic and optimistic yellow sea sponge who lives in a submerged pineapple.",
                    "https://upload.wikimedia.org/wikipedia/en/thumb/3/3b/SpongeBob_SquarePants_character.svg/1920px-SpongeBob_SquarePants_character.svg.png",
                    "https://formatted-decks.s3.amazonaws.com/image/2558569d-fb9b-417f-8500-089eb0efecea.jpg",
                    "Tom Kenny"
                )
            )
            list.add(
                BlogPost(
                    1,
                    "Patrick Star",
                    "A dim-witted yet friendly pink starfish who resides under a rock.",
                    "https://upload.wikimedia.org/wikipedia/en/thumb/3/33/Patrick_Star.svg/1920px-Patrick_Star.svg.png",
                    "https://upload.wikimedia.org/wikipedia/en/thumb/3/33/Patrick_Star.svg/1920px-Patrick_Star.svg.png",
                    " Bill Fagerbakke"
                )
            )

            list.add(
                BlogPost(
                    2,
                    "Squidward Tentacles",
                    "An arrogant, ill-tempered octopus who lives in an Easter Island moai. He enjoys playing the clarinet and painting self-portraits but hates his job as a cashier. ",
                    "https://upload.wikimedia.org/wikipedia/en/thumb/8/8f/Squidward_Tentacles.svg/1920px-Squidward_Tentacles.svg.png",
                    "https://media.entertainmentearth.com/assets/images/d4d3f0da232b4cc6af37cd824c5f60a8xl.jpg",
                    "Rodger Bumpass"
                )
            )
            list.add(
                BlogPost(
                    3,
                    " Mr. Krabs",
                    "The owner of the Krusty Krab.",
                    "https://upload.wikimedia.org/wikipedia/en/thumb/f/f8/Mr._Krabs.svg/1920px-Mr._Krabs.svg.png",
                    "https://upload.wikimedia.org/wikipedia/en/thumb/f/f8/Mr._Krabs.svg/1920px-Mr._Krabs.svg.png",
                    "Clancy Brown"
                )
            )
            list.add(
                BlogPost(
                    4,
                    "Pearl Krabs",
                    "A teenage sperm whale who lives in a hollow anchor with her father Eugene Krabs, aka Mr. Krabs.",
                    "https://upload.wikimedia.org/wikipedia/en/thumb/5/5d/Pearl_the_Whale.svg/1920px-Pearl_the_Whale.svg.png",
                    "https://upload.wikimedia.org/wikipedia/en/thumb/5/5d/Pearl_the_Whale.svg/1920px-Pearl_the_Whale.svg.png",
                    "Lori Alan"
                )
            )
            list.add(
                BlogPost(
                    5,
                    "Sandy Cheeks",
                    "A thrill-seeking and athletic squirrel from Texas, who wears an air-filled diving suit to breathe underwater.",
                    "https://upload.wikimedia.org/wikipedia/en/thumb/a/a0/Sandy_Cheeks.svg/1920px-Sandy_Cheeks.svg.png",
                    "https://upload.wikimedia.org/wikipedia/en/thumb/a/a0/Sandy_Cheeks.svg/1920px-Sandy_Cheeks.svg.png",
                    "Caroline Lacroix"
                )
            )
            list.add(
                BlogPost(
                    6,
                    "Plankton",
                    "Is the nemesis and former best friend of Mr. Krabs, He is the owner of the Chum Bucket, a fast food restaurant located directly across the street from Krabs' restaurant.",
                    "https://static.wikia.nocookie.net/characters/images/4/47/Plankton.png/revision/latest?cb=20171222013746",
                    "https://64.media.tumblr.com/3afbefb8dc2623f879d075090e1f1a93/tumblr_pbwwoqJ8gI1u8kct5o1_500.jpg",
                    "Douglas Lawrence "
                )
            )
            list.add(
               BlogPost(
                   7,
                   "Karen",
                   "Plankton's wife is a waterproof supercomputer named Karen, who is also his sidekick and best friend.",
                   "https://static.wikia.nocookie.net/spongebob/images/1/18/Karen-blue-form-stock-art.png/revision/latest?cb=20200317150606",
                   "https://64.media.tumblr.com/3afbefb8dc2623f879d075090e1f1a93/tumblr_pbwwoqJ8gI1u8kct5o1_500.jpg",
                   "Jill Meyers"

                )
            )
            return list
        }
    }
}